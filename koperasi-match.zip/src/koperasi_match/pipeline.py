from collections import Counter

from .address_parser import parse_address
from .config import DuplicatePolicy, MatchConfig
from .matcher import Matcher
from .models import MatchResult
from .report_writer import write_report
from .workbook_reader import read_reference, read_sources


def run(config: MatchConfig) -> Counter[str]:
    sources = read_sources(config.source, config.sheets, config.address_column)
    headers, references, _ = read_reference(config.reference, config.reference_sheet)
    key_counts = Counter(
        (item.province, item.desa, item.kecamatan, item.kabupaten) for item in references
    )
    duplicate_reference_count = sum(1 for count in key_counts.values() if count > 1)
    matcher = Matcher(references, config.threshold, config.minimum_margin)
    results: list[MatchResult] = []
    seen_reference_rows: set[int] = set()
    for source in sources:
        source.parsed = parse_address(source.address, source.province)
        result = matcher.match(source)
        if result.is_matched and result.reference and result.reference.row in seen_reference_rows:
            if config.duplicate_policy == DuplicatePolicy.FIRST:
                continue
            if config.duplicate_policy == DuplicatePolicy.ERROR:
                raise ValueError(
                    f"Record referensi baris {result.reference.row} cocok lebih dari sekali"
                )
        if result.is_matched and result.reference:
            seen_reference_rows.add(result.reference.row)
        results.append(result)
    write_report(
        config.output,
        headers,
        results,
        config.source,
        config.reference,
        config.sheets,
        config.threshold,
        config.minimum_margin,
        duplicate_reference_count,
    )
    return Counter(result.status.value for result in results)
