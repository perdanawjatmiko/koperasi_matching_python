# koperasi-match

CLI Python untuk mencocokkan alamat gabungan pada workbook sumber dengan data koperasi dalam workbook referensi. Semua kolom pada baris referensi yang cocok dibawa ke sheet `MATCHED`.

## Instalasi

Membutuhkan Python 3.12 atau lebih baru.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
```

Workbook referensi default harus tersedia di `docs/referensi_koperasi.xlsx`. Lokasinya dihitung dari root project sehingga command dapat dijalankan dari direktori mana pun.

## Penggunaan

Referensi default:

```bash
koperasi-match match /path/testcleaning.xlsx \
  --sheet ACEH --sheet SUMUT \
  --output /path/hasil_pencocokan.xlsx
```

Referensi lain:

```bash
koperasi-match match /path/testcleaning.xlsx \
  --reference /path/referensi_lain.xlsx \
  --sheet ACEH --sheet SUMUT \
  --output /path/hasil.xlsx
```

Periksa struktur workbook:

```bash
koperasi-match inspect /path/file.xlsx
```

Gunakan `koperasi-match match --help` untuk seluruh opsi. Output yang sudah ada hanya dapat ditimpa dengan `--overwrite`.

## Cara pencocokan

Urutan pencocokan adalah exact provinsi–desa–kecamatan–kabupaten, kombinasi unik desa–kecamatan, alias, lalu fuzzy matching yang dibatasi berdasarkan provinsi dan wilayah yang tersedia. Nilai default fuzzy adalah threshold 90 dan margin kandidat 5.

Status otomatis:

- `MATCHED_EXACT`
- `MATCHED_UNIQUE_DESA_KECAMATAN`
- `MATCHED_ALIAS`
- `MATCHED_FUZZY`

Hasil yang belum aman dipilih masuk `PERLU_REVIEW`. Alamat yang tidak dapat diparsing atau tidak memiliki kandidat masuk `TIDAK_DITEMUKAN`.

## Output

- `RINGKASAN`: parameter dan jumlah setiap status.
- `MATCHED`: semua kolom asli referensi ditambah kolom audit.
- `PERLU_REVIEW`: tiga kandidat terbaik dan skor.
- `TIDAK_DITEMUKAN`: alamat serta alasan kegagalan.

Kebijakan duplikasi record referensi yang sama dapat diatur dengan `--duplicate-policy keep|first|error`.

## Alias

Alias provinsi dan wilayah berada di `src/koperasi_match/normalizer.py`. Tambahkan pasangan nama baru ke `PROVINCE_ALIASES` atau `REGION_ALIASES`, lalu tambahkan pengujiannya.

## Batasan

- Parser berbasis aturan dan tidak memakai layanan internet atau AI.
- Alamat tanpa struktur yang cukup akan masuk pemeriksaan manual.
- Fuzzy match tidak menjamin nama administratif telah diperbarui; periksa sheet `PERLU_REVIEW`.
