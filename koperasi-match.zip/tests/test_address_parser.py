from koperasi_match.address_parser import parse_address


def test_parse_comma_and_trailing_comma():
    parsed = parse_address("Paya Bakung, Hamparan Perak, Deli Serdang,", "SUMUT")
    assert (parsed.desa, parsed.kecamatan, parsed.kabupaten, parsed.province) == (
        "PAYA BAKUNG",
        "HAMPARAN PERAK",
        "DELI SERDANG",
        "SUMATERA UTARA",
    )


def test_parse_labels():
    parsed = parse_address("DESA SAWO KEC. SAWO KAB. NIAS UTARA", "SUMUT")
    assert (parsed.desa, parsed.kecamatan, parsed.kabupaten) == ("SAWO", "SAWO", "NIAS UTARA")


def test_parse_dot_format():
    parsed = parse_address("DESA KEUDE LAPANG. LAPANG. ACEH UTARA", "ACEH")
    assert not parsed.error
    assert parsed.kecamatan == "LAPANG"


def test_parse_failed():
    assert parse_address("TIDAK JELAS", "ACEH").error
