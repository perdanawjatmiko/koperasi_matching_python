from pathlib import Path

from openpyxl import Workbook, load_workbook

from koperasi_match.config import MatchConfig
from koperasi_match.pipeline import run


def _save_source(path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "ACEH"
    ws.append(["PROVINSI ACEH"])
    ws.append(["NO", "ALAMAT"])
    ws.append([1, "LAYEUN, LEUPUNG, ACEH BESAR"])
    wb.save(path)


def _save_reference(path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Export Laporan"
    ws.append(["NIK", "desa", "kecamatan", "Kota/Kabupaten", "Provinsi", "pic phone"])
    ws.append(["001", "Layeun", "Leupung", "Kabupaten Aceh Besar", "Aceh", "0812"])
    wb.save(path)


def test_pipeline_preserves_inputs_and_identifiers(tmp_path):
    source = tmp_path / "source.xlsx"
    reference = tmp_path / "reference.xlsx"
    output = tmp_path / "output.xlsx"
    _save_source(source)
    _save_reference(reference)
    source_before = source.read_bytes()
    reference_before = reference.read_bytes()
    counts = run(MatchConfig(source=source, reference=reference, output=output, sheets=["ACEH"]))
    assert counts["MATCHED_EXACT"] == 1
    assert source.read_bytes() == source_before
    assert reference.read_bytes() == reference_before
    wb = load_workbook(output, data_only=True)
    assert wb["MATCHED"]["A2"].value == "001"
    assert wb["MATCHED"]["F2"].value == "0812"
    assert wb.sheetnames == ["RINGKASAN", "MATCHED", "PERLU_REVIEW", "TIDAK_DITEMUKAN"]
